package com.example.pruebaactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button btn_prueba,btn_prueba2,btn_prueba3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn_prueba = findViewById(R.id.btn_prueba);
        Button btn_prueba2 = findViewById(R.id.btn_prueba2);
        Button btn_prueba3 = findViewById(R.id.btn_prueba3);

        btn_prueba.setOnClickListener(v -> Toast.makeText(this, "Boton 1", Toast.LENGTH_SHORT).show());
        btn_prueba2.setOnClickListener(v -> Toast.makeText(this, "Boton 2", Toast.LENGTH_SHORT).show());
        btn_prueba3.setOnClickListener(v -> Toast.makeText(this, "Boton 3", Toast.LENGTH_SHORT).show());
    }
}